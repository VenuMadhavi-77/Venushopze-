const express = require('express');
const router = express.Router();
const Product = require('../models/Product');
const Review = require('../models/Review');
const { protect, authorize } = require('../middlewares/auth');

// Helper to escape regex special characters for an exact keyword match
function escapeRegExp(string) {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

// @route   GET /api/products
// @desc    Get all products (with filters & exact search)
router.get('/', async (req, res) => {
  try {
    const { category, search, minPrice, maxPrice, sellerId } = req.query;
    let query = {};

    if (category) {
      query.category = category;
    }

    if (sellerId) {
      query.seller = sellerId;
    }

    // Exact keyword search match on name or description (case-insensitive substring)
    if (search) {
      const cleanSearch = escapeRegExp(search.trim());
      query.$or = [
        { name: { $regex: cleanSearch, $options: 'i' } },
        { description: { $regex: cleanSearch, $options: 'i' } }
      ];
    }

    if (minPrice || maxPrice) {
      query.price = {};
      if (minPrice) query.price.$gte = Number(minPrice);
      if (maxPrice) query.price.$lte = Number(maxPrice);
    }

    const products = await Product.find(query).populate('seller', 'name email').sort({ createdAt: -1 });
    res.json(products);
  } catch (error) {
    console.error('Fetch products error:', error);
    res.status(500).json({ message: 'Server error fetching products' });
  }
});

// @route   GET /api/products/:id
// @desc    Get single product details
router.get('/:id', async (req, res) => {
  try {
    const product = await Product.findById(req.params.id).populate('seller', 'name email');
    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }
    res.json(product);
  } catch (error) {
    console.error('Fetch single product error:', error);
    res.status(500).json({ message: 'Server error fetching product details' });
  }
});

// @route   POST /api/products
// @desc    Create a new product (Sellers & Admins)
router.post('/', protect, authorize('seller', 'admin'), async (req, res) => {
  try {
    const { name, description, price, originalPrice, category, stock, images, specs } = req.body;

    if (!name || !description || !price || !originalPrice || !category || !images || images.length === 0) {
      return res.status(400).json({ message: 'Please fill all required fields' });
    }

    const product = await Product.create({
      name,
      description,
      price: Number(price),
      originalPrice: Number(originalPrice),
      category,
      stock: Number(stock) || 0,
      images,
      specs: specs || {},
      seller: req.user._id
    });

    res.status(201).json(product);
  } catch (error) {
    console.error('Create product error:', error);
    res.status(500).json({ message: 'Server error creating product' });
  }
});

// @route   PUT /api/products/:id
// @desc    Update a product (Sellers & Admins)
router.put('/:id', protect, authorize('seller', 'admin'), async (req, res) => {
  try {
    let product = await Product.findById(req.params.id);

    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }

    // If seller, ensure they own the product
    if (req.user.role === 'seller' && product.seller.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized to update this product' });
    }

    const { name, description, price, originalPrice, category, stock, images, specs } = req.body;

    product.name = name || product.name;
    product.description = description || product.description;
    product.price = price !== undefined ? Number(price) : product.price;
    product.originalPrice = originalPrice !== undefined ? Number(originalPrice) : product.originalPrice;
    product.category = category || product.category;
    product.stock = stock !== undefined ? Number(stock) : product.stock;
    product.images = images || product.images;
    product.specs = specs || product.specs;

    const updatedProduct = await product.save();
    res.json(updatedProduct);
  } catch (error) {
    console.error('Update product error:', error);
    res.status(500).json({ message: 'Server error updating product' });
  }
});

// @route   DELETE /api/products/:id
// @desc    Delete a product (Sellers & Admins)
router.delete('/:id', protect, authorize('seller', 'admin'), async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);

    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }

    // If seller, ensure they own the product
    if (req.user.role === 'seller' && product.seller.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized to delete this product' });
    }

    await Product.findByIdAndDelete(req.params.id);
    // Delete reviews of this product as well
    await Review.deleteMany({ product: req.params.id });

    res.json({ message: 'Product and associated reviews deleted successfully' });
  } catch (error) {
    console.error('Delete product error:', error);
    res.status(500).json({ message: 'Server error deleting product' });
  }
});

// @route   GET /api/products/:id/reviews
// @desc    Get reviews for a product
router.get('/:id/reviews', async (req, res) => {
  try {
    const reviews = await Review.find({ product: req.params.id }).populate('user', 'name').sort({ createdAt: -1 });
    res.json(reviews);
  } catch (error) {
    console.error('Fetch reviews error:', error);
    res.status(500).json({ message: 'Server error fetching reviews' });
  }
});

// @route   POST /api/products/:id/reviews
// @desc    Add review to a product
router.post('/:id/reviews', protect, async (req, res) => {
  try {
    const { rating, comment } = req.body;
    const product = await Product.findById(req.params.id);

    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }

    if (!rating || !comment) {
      return res.status(400).json({ message: 'Rating and comment are required' });
    }

    // Check if user already reviewed
    const alreadyReviewed = await Review.findOne({ user: req.user._id, product: req.params.id });
    if (alreadyReviewed) {
      return res.status(400).json({ message: 'Product already reviewed by this user' });
    }

    const review = await Review.create({
      user: req.user._id,
      userName: req.user.name,
      product: req.params.id,
      rating: Number(rating),
      comment
    });

    // Re-calculate ratings average
    const reviews = await Review.find({ product: req.params.id });
    const ratingsCount = reviews.length;
    const ratingsAverage = reviews.reduce((acc, item) => item.rating + acc, 0) / ratingsCount;

    product.ratings.count = ratingsCount;
    product.ratings.average = Math.round(ratingsAverage * 10) / 10; // 1 decimal place

    await product.save();

    res.status(201).json(review);
  } catch (error) {
    console.error('Submit review error:', error);
    res.status(500).json({ message: 'Server error submitting review' });
  }
});

module.exports = router;
